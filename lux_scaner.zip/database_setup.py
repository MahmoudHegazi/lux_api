#!/usr/bin/env python3
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine


Base = declarative_base()



class FreshFoodLinks(Base):
    __tablename__ = 'freshfood_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class FreshFood(Base):
    __tablename__ = 'fresh_food'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }


class GroceryLinks(Base):
    __tablename__ = 'gorcery_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class Grocery(Base):
    __tablename__ = 'grocery'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }


class BabyLinks(Base):
    __tablename__ = 'baby_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class Baby(Base):
    __tablename__ = 'baby'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }



class DrinksLinks(Base):
    __tablename__ = 'drinks_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class Dinks(Base):
    __tablename__ = 'drinks'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }


class ChildAndFrozenLinks(Base):
    __tablename__ = 'child_and_frozen_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class ChildAndFrozen(Base):
    __tablename__ = 'child_and_frozed'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }


class HealthAndBeautyLinks(Base):
    __tablename__ = 'health_and_beauty_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class HealthAndBeauty(Base):
    __tablename__ = 'health_and_beauty'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }


class HouseholdLinks(Base):
    __tablename__ = 'hosehold_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class Household(Base):
    __tablename__ = 'household'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }


class PetsLinks(Base):
    __tablename__ = 'pets_links'

    id = Column(Integer, primary_key=True)
    url = Column(String(255))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'url': self.url,
            'market_place':self.market_place,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }

class Pets(Base):
    __tablename__ = 'pets'

    id = Column(Integer, primary_key=True)
    name = Column(String(255))
    price = Column(String(60))
    image = Column(String(350))
    image_list = Column(String(350))
    tags = Column(String(350))
    market_place = Column(String(50))
    last_update = Column(String(255))
    last_update_text = Column(String(255))
    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'price': self.price,
            'image': self.image,
            'image_list':self.image_list,
            'tags':self.tags,
            'last_update':self.last_update,
            'last_update':self.last_update,
            'last_update_text':self.last_update_text,
        }
engine = create_engine('sqlite:///lux_scaner.db')
Base.metadata.create_all(engine)
